# PyCon Hangzhou Slides

《如何维护自己的Side Project》

在线预览: [Gitpitch](https://gitpitch.com/laixintao/side-project-slide)
